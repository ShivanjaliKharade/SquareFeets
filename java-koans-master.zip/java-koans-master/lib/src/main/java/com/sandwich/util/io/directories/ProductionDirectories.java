package com.sandwich.util.io.directories;


public class ProductionDirectories extends DirectorySet {

	public String getProjectDir() {
		return "koans";
	}
	
	public String getSourceDir() {
		return "src";
	}
	
}
