import Login from "../components/Login";
import SFNav from "../components/Navbar";

export default function LoginPage() {
  return (
    <div>
      <SFNav />
      <Login />
    </div>
  );
}
