import "bootstrap/dist/css/bootstrap.css"
import 'bootstrap/dist/css/bootstrap.min.css';

import { Navigate, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";

import LoginPage from "./pages/LoginPage";
import Footer from "./components/Footer";
import CustomerRegistrationPage from "./pages/Customer-Registration-Page";
import BuilderRegisterPage from "./pages/Builder-Registration-Page";
import Properties from "./pages/Properties";
import PropertyInfo from "./components/PropertyInfo";
import CustomerProfilePage from "./pages/Customer-Profile-Page";
import BuilderProfile from "./pages/Builder-Profile-Page";
import AdminPage from "./pages/AdminPage";
import AdminBuilderList from "./pages/AdminBuilderList"
import AdminPropList from "./pages/AdminPropList";
import Aboutus from "./pages/Aboutus";
import Contact from "./pages/Contact";
import ChangePassword from "./pages/ChangePassword";
import UpdateProperty from "./pages/UpdateProperty";
import ForgetPassword from "./pages/ForgetPassword";
import ForgetPassword2 from "./pages/ForgetPassword2";
import ErrorPage from "./Error/ErrorPages";
import ResetPassword from "./pages/ResetPassword";
import AddProperty from "./pages/AddProperty";
import Payment from "./pages/Payment";

function App() {

  // localStorage.setItem("isLogin", null)
  // const [logVal, setLogVal] = useState(null);
  // setLogVal(localStorage.getItem("isLogin"));

  // console.log(logVal);

  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="Login" element={<LoginPage />} />
        <Route
          path="Customer-Registration"
          element={<CustomerRegistrationPage />}
        />
        <Route path="Builder-Registration" element={<BuilderRegisterPage />} />

        <Route path="Properties" element={<Properties />} />
        {/* <Route
          path="Properties"
          element={
            <ProtectedRoute>
              <Properties />
            </ProtectedRoute>
          }
        /> */}


        {/* <Route path="PropertiesInfo" element={<PropertyInfo />} /> */}
        <Route
          path="PropertiesInfo"
          element={
            <ProtectedRoute>
              <PropertyInfo />
            </ProtectedRoute>
          }
        />

        {/* <Route path="CustomerProfile" element={<CustomerProfilePage />} /> */}
        <Route
          path="CustomerProfile"
          element={
            <ProtectedRoute>
              <CustomerProfilePage />
            </ProtectedRoute>
          }
        />

        {/* <Route path="BuilderProfile" element={<BuilderProfile />} /> */}
        <Route
          path="BuilderProfile"
          element={
            <ProtectedRoute>
              <BuilderProfile />
            </ProtectedRoute>
          }
        />

        {/* <Route path="AdminPage" element={<AdminPage />} /> */}
        <Route
          path="AdminPage"
          element={
            <ProtectedRoute>
              <AdminPage />
            </ProtectedRoute>
          }
        />

        {/* <Route path="AdminBuilderList" element={<AdminBuilderList />} /> */}
        <Route
          path="AdminBuilderList"
          element={
            <ProtectedRoute>
              <AdminBuilderList />
            </ProtectedRoute>
          }
        />

        {/* <Route path="AdminPropList" element={<AdminPropList />} /> */}
        <Route
          path="AdminPropList"
          element={
            <ProtectedRoute>
              <AdminPropList />
            </ProtectedRoute>
          }
        />

        <Route path="Aboutus" element={<Aboutus />} />

        {/* <Route path="Contactus" element={<Contact />} /> */}
        <Route
          path="Contactus"
          element={
            <ProtectedRoute>
              <Contact />
            </ProtectedRoute>
          }
        />

        {/* <Route path="ChangePassword" element={<ChangePassword />} /> */}
        <Route
          path="ChangePassword"
          element={
            <ProtectedRoute>
              <ChangePassword />
            </ProtectedRoute>
          }
        />

        {/* <Route path="UpdateProperty" element={<UpdateProperty />} /> */}
        <Route
          path="UpdateProperty"
          element={
            <ProtectedRoute>
              <UpdateProperty />
            </ProtectedRoute>
          }
        />

        <Route path="ForgetPassword" element={<ForgetPassword />} />
        <Route path="ForgetPassword2" element={<ForgetPassword2 />} />
        <Route path="ResetPassword" element={<ResetPassword />} />

        {/* <Route path="AddProperty" element={<AddProperty />} /> */}
        <Route
          path="AddProperty"
          element={
            <ProtectedRoute>
              <AddProperty />
            </ProtectedRoute>
          }
        />

        <Route path="ErrorPage" element={<ErrorPage />} />
        {/* <Route path="Payment" element={<Payment />} /> */}
        <Route
          path="Payment"
          element={
            <ProtectedRoute>
              <Payment />
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<ErrorPage />} />
      </Routes>
      <Footer />
    </div>
  );
}

function ProtectedRoute({ children }) {
  let myjwt = localStorage.getItem("loginData");

  // IF NOT LOGGED IN :: REDIRECT THE USER TO LOGIN
  if (!myjwt) {
    return <Navigate to="/login" replace={true} />;
  }

  return children;
}

function UnProtectedRoute({ children }) {
  let myjwt = localStorage.getItem("loginData");

  if (myjwt) {
    return <Navigate to="/" replace={true} />;
  }

  return children;
}

export default App;
