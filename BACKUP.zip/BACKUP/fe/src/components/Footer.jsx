import "./styles/Footer.css";
import twitterLogo from "../images/icons8-twitter-144.svg";
import facebookLogo from "../images/icons8-facebook-144.svg";
import instagramLogo from "../images/icons8-instagram-144.svg";
import whatsappLogo from "../images/icons8-whatsapp-144.svg";

export default function Footer() {
  return (
    <div>
      <div class="footer-dark">
        <footer>
          <div class="container">
            <div class="row">
              <div class="col-md-3 item">
                <h3>Our Services</h3>
                <ul>
                  <li>
                    <a href="#">Buy Property</a>
                  </li>
                  <li>
                    <a href="#">Post Your Property</a>
                  </li>
                  <li>
                    <a href="#">Book Appointment</a>
                  </li>
                </ul>
              </div>
              <div class="col-md-3 item">
                <h3>Company</h3>
                <ul>
                  <li>
                    <a href="#">About Us</a>
                  </li>
                  <li>
                    <a href="#">Contact Us</a>
                  </li>
                  <li>
                    <a href="#">Feedback</a>
                  </li>
                </ul>
              </div>
              <div class="col-md-3 item">
                <h3>About</h3>
                <ul>
                  <li>
                    <a href="#">Company</a>
                  </li>
                  <li>
                    <a href="#">Team</a>
                  </li>
                </ul>
              </div>
              <div class="col-md-3 item text">
                <h3>SquareFeets</h3>
                <p>Your One Stop Property Buying and Selling Site</p>
              </div>
              <div class="col item social">
                {/* <a href="#"> */}
                <img
                  src={twitterLogo}
                  alt=""
                  width="40px"
                  style={{ margin: "10px" }}
                />
                {/* </a>
                <a href="#"> */}
                <img
                  src={whatsappLogo}
                  alt=""
                  width="40px"
                  style={{ margin: "10px" }}
                />
                {/* </a>
                <a href="#"> */}
                <img
                  src={facebookLogo}
                  alt=""
                  width="40px"
                  style={{ margin: "10px" }}
                />
                {/* </a>
                <a href="#"> */}
                <img
                  src={instagramLogo}
                  alt=""
                  width="40px"
                  style={{ margin: "10px" }}
                />
                {/* </a> */}
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
