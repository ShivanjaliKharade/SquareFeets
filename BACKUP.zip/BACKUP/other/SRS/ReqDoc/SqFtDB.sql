create database Squarefeets;
use Squarefeets;
show tables;

create Table Roles(
role_id int primary key auto_increment,
role_type varchar(20) not null
);

create table Address(
address_id int primary key auto_increment , 
plot_no int Not Null,
street varchar(20) Not Null,
landmark varchar(50),
city varchar(20) Not Null,
state varchar(20) Not Null , 
pincode int Not Null
);

Create table User_Details(
user_details_id int primary key auto_increment,
role_id int,
user_name varchar(40),
user_password varchar(16),
email varchar(25) not null unique,
mobile_no bigint not null unique,
address_id int,
aadhar_no bigint not null unique,
foreign key (role_id) references Roles(role_id),
foreign key (address_id) references Address(address_id)
);

create table Builder(
user_details_id int,
builder_license varchar(50) not null unique,
foreign key (user_details_id) references User_Details(user_details_id) 
);

create table Property_Type(
property_type_id int primary key auto_increment,
property_type varchar(40)
);

create table Property(
property_id int primary key auto_increment,
property_type_id int,
address_id int,
user_details_id int,
property_name varchar(30) Not Null,
details varchar(50),
price int not null,
construction_status varchar(60),
RERA_reg varchar(20) not null unique,
area varchar(25) not null,
rooms varchar(10),
foreign key (property_type_id) references Property_Type(property_type_id),
foreign key (address_id) references Address(address_id),
foreign key (user_details_id) references User_Details(user_details_id) 
);

create table Property_Images(
img_id int primary key auto_increment,
property_id int,
image_name varchar(20),
img_description varchar(50),
foreign key (property_id) references Property(property_id)
);

create table Payment_Gateway(
payment_id int primary key auto_increment,
user_details_id int,
property_id int,
payment_type varchar(40) not null,
date_time datetime not null,
amount_paid decimal not null,
transaction_id varchar(25) not null,
payment_status varchar(100) not null,
foreign key (user_details_id) references User_Details(user_details_id),
foreign key (property_id) references Property(property_id)
);

create table Feedback(
feedback_id int primary key auto_increment,
user_details_id int,
property_id int,
rating int,
comments varchar(200),
foreign key (user_details_id) references User_Details(user_details_id),
foreign key (property_id) references Property(property_id)
);

create table Appointment(
app_id int primary key auto_increment,
user_details_id int,
property_id int,
date_time datetime not null,
appointment_status varchar(200),
foreign key (user_details_id) references User_Details(user_details_id),
foreign key (property_id) references Property(property_id)
);
