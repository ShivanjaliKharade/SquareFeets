create database Squarefeets;

create Table Admins(
admin_id int primary key auto_increment,
admin_name varchar(30) Not Null,
admin_password varchar(16) Not Null
);

create table Address(
address_id int primary key auto_increment , 
plot_no int Not Null,
street varchar(20) Not Null,
landmark varchar(50),
city varchar(20) Not Null,
state varchar(20) Not Null , 
pincode int Not Null
);


Create table Users(
user_id int primary key auto_increment,
user_name varchar(40),
user_password varchar(16),
email varchar(25) not null unique,
mobile_no bigint not null unique,
address_id int,
aadhar_no bigint not null unique,
foreign key (address_id) references Address(address_id)
);

create table Property_Type(
property_type_id int primary key auto_increment,
property_type varchar(40)
);

create table Builder(
builder_id int primary key auto_increment,
builder_name varchar(40),
builder_password varchar(16),
builder_email varchar(25) not null unique,
builder_mobile_no bigint not null unique,
builder_aadhar_no bigint not null unique,
builder_license varchar(50) not null unique 
);

create table Property(
property_id int primary key auto_increment,
property_type_id int,
address_id int,
builder_id int,
property_name varchar(30) Not Null,
details varchar(50),
price int not null,
construction_status varchar(60),
RERA_reg varchar(20) not null unique,
area varchar(25) not null,
rooms varchar(10),
foreign key (property_type_id) references Property_Type(property_type_id),
foreign key (address_id) references Address(address_id),
foreign key (builder_id) references Builder(builder_id)
);


create table Property_Images(
img_id int primary key auto_increment,
property_id int,
image_name varchar(20),
img_description varchar(50),
foreign key (property_id) references Property(property_id)
);

create table Payment_Gateway(
payment_id int primary key auto_increment,
user_id int,
property_id int,
payment_type varchar(40) not null,
date_time datetime not null,
amount_paid decimal not null,
transaction_id varchar(25) not null,
payment_status varchar(100) not null,
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id)
);

create table Feedback(
feedback_id int primary key auto_increment,
user_id int,
property_id int,
rating int,
comments varchar(200),
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id)
);

create table Appointment(
app_id int primary key auto_increment,
user_id int,
builder_id int,
property_id int,
date_time datetime not null,
appointment_status varchar(200),
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id),
foreign key (builder_id) references Builder(builder_id)
);






















