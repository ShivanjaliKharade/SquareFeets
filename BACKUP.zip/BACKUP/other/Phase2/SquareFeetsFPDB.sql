create database squarefeetsfp;
use squarefeetsfp;
show tables;
desc property;
drop database squarefeetsfp;

CREATE TABLE SPRING_SESSION (
PRIMARY_ID CHAR(36) NOT NULL,
SESSION_ID CHAR(36) NOT NULL,
CREATION_TIME BIGINT NOT NULL,
LAST_ACCESS_TIME BIGINT NOT NULL,
MAX_INACTIVE_INTERVAL INT NOT NULL,
EXPIRY_TIME BIGINT NOT NULL,
PRINCIPAL_NAME VARCHAR(100),
CONSTRAINT SPRING_SESSION_PK PRIMARY KEY (PRIMARY_ID)
);

CREATE UNIQUE INDEX SPRING_SESSION_IX1 ON SPRING_SESSION (SESSION_ID);
CREATE INDEX SPRING_SESSION_IX2 ON SPRING_SESSION (EXPIRY_TIME);
CREATE INDEX SPRING_SESSION_IX3 ON SPRING_SESSION (PRINCIPAL_NAME);

CREATE TABLE SPRING_SESSION_ATTRIBUTES (
SESSION_PRIMARY_ID CHAR(36) NOT NULL,
ATTRIBUTE_NAME VARCHAR(200) NOT NULL,
ATTRIBUTE_BYTES BLOB NOT NULL,
CONSTRAINT SPRING_SESSION_ATTRIBUTES_PK PRIMARY KEY (SESSION_PRIMARY_ID, ATTRIBUTE_NAME),
CONSTRAINT SPRING_SESSION_ATTRIBUTES_FK FOREIGN KEY (SESSION_PRIMARY_ID) REFERENCES SPRING_SESSION(PRIMARY_ID) ON DELETE CASCADE
);

create table Property_Type(
property_type_id int primary key auto_increment,
property_type varchar(40)
);

create table Property(
property_id int primary key auto_increment,
property_type_id int,
address_id bigint,
user_id bigint,
property_name varchar(30) Not Null,
details varchar(50),
price double not null,
construction_status varchar(60),
RERA_reg varchar(20) not null unique,
area double not null,
rooms varchar(10),
foreign key (property_type_id) references Property_Type(property_type_id),
foreign key (address_id) references Address(address_id),
foreign key (user_id) references Users(user_id) 
);

create table Property_Images(
img_id int primary key auto_increment,
property_id int,
image_name varchar(20),
img_description varchar(50),
foreign key (property_id) references Property(property_id)
);

create table Payment_Gateway(
payment_id int primary key auto_increment,
user_id bigint,
property_id int,
payment_type varchar(40) not null,
date_time datetime not null,
amount_paid decimal not null,
transaction_id varchar(25) not null,
payment_status varchar(100) not null,
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id)
);

create table Feedback(
feedback_id int primary key auto_increment,
user_id bigint,
property_id int,
rating int,
comments varchar(200),
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id)
);

create table Appointment(
app_id int primary key auto_increment,
user_id bigint,
property_id int,
date_time datetime not null,
appointment_status varchar(200),
foreign key (user_id) references Users(user_id),
foreign key (property_id) references Property(property_id)
);

INSERT INTO roles(name) VALUES('ROLE_ADMIN');
INSERT INTO roles(name) VALUES('ROLE_BUILDER');
INSERT INTO roles(name) VALUES('ROLE_CUSTOMER');


INSERT INTO Property_Type VALUES(1,'Residential');
INSERT INTO Property_Type VALUES(2,'Residential-Building');
INSERT INTO Property_Type VALUES(3,'Residential-Villa');
INSERT INTO Property_Type VALUES(4,'Residential-Bunglow');
INSERT INTO Property_Type VALUES(5,'Commercial');

INSERT INTO Property VALUES(56,3, 3, null, 'Saurabh', 'Bunglow', 14000, 'Completed', 'skyj4845', '2000sqft', 30, null, 8, 3);
INSERT INTO Property VALUES(51,3, 7, null, 'hdb', 'Bunglow', 13000, 'inprogress', 'nkj879', '2000sqft', 30, null, 8, 3);

INSERT INTO Builder VALUES(6,"Not Approved", 847596,null,1,null);

select * from Users;
select * from address;
select * from roles;
select * from builder;
select * from user_roles;
select * from Property;
select * from Appointment;
select * from Feedback;

delete from Property where property_id=21;

select * from Property_Type;
select * from SPRING_SESSION;
select * from SPRING_SESSION_ATTRIBUTES;



desc Property;
desc Appointment;
desc Feedback;

alter table Appointment modify date_time date;
truncate table Appointment;
