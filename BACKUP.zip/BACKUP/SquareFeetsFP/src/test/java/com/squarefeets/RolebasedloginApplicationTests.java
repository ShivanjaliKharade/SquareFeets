package com.squarefeets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolebasedloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
